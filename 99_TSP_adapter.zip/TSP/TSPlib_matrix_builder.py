# -*- coding: utf-8 -*-
"""
Created on Mon Aug  8 10:03:37 2016

@author: ivan
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import distance

#IN = "14Burma/burma14.tsp"; NAME = "14Burma"
#IN = "16Ulysses/ulysses16.tsp"; NAME = "16Ulysses"
#IN = "48US/att48.tsp"; NAME = "48att"
#IN = "52Berlin/berlin52.tsp"; NAME = "52Berlin"
#IN = "96Africa/gr96.tsp"; NAME = "96gr"
#IN = "137America/gr137.tsp"; NAME = "137gr"
#IN = "264City/pr264.tsp"; NAME = "264pr"
#IN = "318City/lin318.tsp"; NAME = "318lin"
#IN = "535Airports/ali535.tsp"; NAME = "535ali"
IN = "50Circ/myTPScurve_50_CIRC.tsp"; NAME = "50Circ"
IN = "24Liss/myTPScurve_24_LISS32.tsp"; NAME = "24Liss"
IN = "76Pr/pr76.tsp"; NAME = "76Pr"
IN = "96Rat/rat96.tsp"; NAME = "96Rat"
IN = "105Lin/lin105.tsp"; NAME = "105Lin"
IN = "130Ch/ch130.tsp"; NAME = "130Ch"

#--------------- READING --------------------
RUTA = IN.split('/')[:-1]
OUT = ""
for carpeta in RUTA: OUT += carpeta
OUT += "/" + NAME + ".txt"
myFile = open(IN,'r')
valid_info = False
cities = []
for line in myFile:
    if line[:18] == "NODE_COORD_SECTION":
        valid_info = True
    if line[:3] == "EOF":
        valid_info = False

    if valid_info and line[:18] != "NODE_COORD_SECTION":
        data_line = line.split()
#        print data_line
        cities.append([float(data_line[1]), float(data_line[2])])
myFile.close()

N = len(cities)

print
print "--- TSP MATRIX BUILDER 1.0 ---"
print
print N, "cities read from", IN
print

#-------------- COMPUTING -------------------
distances = distance.cdist(cities, cities, 'euclidean') + np.eye(len(cities)) * 999999

X = np.array(cities)


#------------- PLOTTING -----------------------
print "Showing map..."
print

plt.plot(X[:,0], X[:,1],'ro')
plt.show()

#-------------- SAVING -----------------------
Xf = distances.flatten()
text = ""
for number in Xf: text += (str(number) + '\n')


myFile = open(OUT, 'w')

myFile.write(text)

myFile.close()  

print "Distances saved in", OUT
print
